export const TEST_ADDRESS_NEVER_USE: string

export const TEST_ADDRESS_NEVER_USE_SHORTENED: string

// declare namespace Cypress {
//   // eslint-disable-next-line @typescript-eslint/class-name-casing
//   interface cy {
//     additionalCommands(): void
//   }
// }
