import './'

describe('lib', () => {
  it('exists', () => {
    expect(true).toBeTruthy()
  })
})
